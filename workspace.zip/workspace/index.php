<?php
    require_once('config/dbconnect.php');
    require_once('includes/header.php');
    require_once('includes/nav.php');
?>
<html lang="en">
 <main id="page-main">
 <div class="searchform">
 <form method="post" action="result.php">
  <label id="searchLabel" for="search">Search</label>
 <input type="text" id="search" name="search" placeholder="Search...">
 </form>
 </div>
<!-- <h5 class="login-header"><a href="login.php">LOGIN</a></h5>-->
 </main>
 </html>
 <script type="text/javascript">
 // Using jQuery.
 $(function() {
 $('form').each(function() {
 $(this).find('input').keypress(function(e) {
 // Enter pressed?
 if(e.which == 10 || e.which == 13) {
 $("form:first").submit();
 }
 });
 $(this).find('input[type=submit]').hide();
 });
 });
 </script>
 <?php
    require_once('includes/footer.php');
?>