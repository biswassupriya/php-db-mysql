 <header id="nav">
 <h1>TED500</h1>
 <nav>
  <ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="#">List</a></li>
  <li><a href="#">Search</a></li>
  <li><a href="#">Trade</a></li>
  </ul>
 </nav>
 </header>