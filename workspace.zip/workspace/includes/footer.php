 <footer id="page-footer">
 <p class="button">CHECK US OUT @</p>
 <p>
 <i class="fab fa-facebook social"></i>
 <i class="fab fa-twitter-square social"></i>
 </p>
 <p>&copy 2019 - Supriya Biswas</p>
 </footer>
 </body>
</html>